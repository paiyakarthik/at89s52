#include<pic.h>
#define DI RB3
#define RW RB4
#define EN RB5
#define RST RB2
#define CS1 RB1
#define CS2 RB0
#define DATA PORTD
#include"pic_adc.h"
#include"GLCD_RW.h"  
#include"fonts.h"
#include"GLCDADC_BAR.h"
unsigned int adcval;
unsigned char x1,y1;
void delay1(unsigned int);
void dec3vbig(unsigned int);
int map(unsigned int x, unsigned int in_min, unsigned int in_max, unsigned int out_min, unsigned int out_max);
void vline();void vline1();void hline();void hline1();
unsigned int f,sec=4,count=0;
void main()
{
	TRISB=0x00;
	TRISD=0x00;
	TRISC=0x00;   
	TRISA=0Xff;
GIE=PEIE=1;
OPTION  = 0b00000101;
TMR0=100;       
TMR0IE=1;
    GLCD_Init();
	Glcdclr();
vline();vline1();hline();hline1();
STR_Printsmall("*MOISTURE:*",25,0);
while(1)
	{
countmy=measure(1);      //**countmy is frequency value**
if(countmy<=368)
{
MOI=adc_calibrate(countmy,0,350);
if(countmy>=360)
{MOI=(368-countmy)*3.62;
MOI=0;}
else if(countmy>=350)
{MOI=(368-countmy)*3.22;
MOI=0;}
else if(countmy>=340)
{MOI=(368-countmy)*2.85;}
else if(countmy>=332)
{MOI=(368-countmy)*2.38;}
else if(countmy>=322)
{MOI=(368-countmy)*2.30;}
else if(countmy>=315)
{MOI=(368-countmy)*2.20;}
else if(countmy>=307)
{MOI=(368-countmy)*1.99;}
else 
{MOI=(368-countmy)*1.87;}
}
else 
MOI=0;
if(sec>=1)
{
if(adcval>255)
{
adcval=255;
}
adcval=MOI; 
dec3vbig((unsigned int)adcval);
Delay(1000);
sec=0;
}
if(MOI!=MOI1){sec=0;MOI1=MOI;}
	}
}
void delay1(unsigned int k)
{
	while(k--);
}

void vline()
{
    xysel(0,0);
	WriteData(0xff);
	xysel(0,1);
	WriteData(0xff);
	xysel(0,2);
	WriteData(0xff);
	xysel(0,3);
	WriteData(0xff);
	xysel(0,4);
	WriteData(0xff);
	xysel(0,5);
	WriteData(0xff);
	xysel(0,6);
	WriteData(0xff);
	xysel(0,7);
	WriteData(0xff);

}

void vline1()
{
 for(int kl=0;kl<8;kl++)
    {
    xysel(127,kl);
    WriteData(0xff);
     }
}
void hline()
{
  for(int fo=1;fo<127;fo++){
  xysel(0+fo,0);
  WriteData(0x01);}
}

void hline1()
{
  for(int fo=1;fo<127;fo++){
  xysel(0+fo,7);
	WriteData(0x80);}
}


void dec3vbig( unsigned int r)
{
unsigned int h,hr,t,o;
 h=r/100;
 xysel(5,2);x1=5,y1=2;Writevbig(h*5);
 hr=r%100;
 t=hr/10;
 o=hr%10;
 xysel(35,2);x1=35,y1=2;Writevbig(t*5);
 STR_Print(".",67,4);
 xysel(78,2);x1=78,y1=2;Writevbig(o*5);
 }

void interrupt ISR()
	{
	
 	if(TMR0IF==1) // Timer flag has been triggered due to timer overflow
    {
        TMR0 =100;     //Load the timer Value
        TMR0IF=0;       // Clear timer interrupt flag
        count++;
    } 
    if (count == 100)
    {
        sec+=1;   // hscnd will get incremented for every half second
        count=0;
    }
	}



int map(unsigned int x, unsigned int in_min, unsigned int in_max, unsigned int out_min, unsigned int out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}