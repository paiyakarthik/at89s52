#include<pic.h>
void delay(unsigned int a);
void main()
{
    /*TRISB=0X81;
	TRISA=0X30;
	TRISC=0X0F;
    ADCON1 = 0x07;  // Disable Analog functions*/
	TRISGPIO=0X00;
	//OSCCAL =0Xf0;
   while(1)
   {
	 GP1=0;
	 delay(45);
	 GP1=1;
	 delay(45);
   }
}
void delay(unsigned int a)
{
	while(--a);
}