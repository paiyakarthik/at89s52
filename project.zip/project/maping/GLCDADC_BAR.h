unsigned char x_add=0,y_add=0,x,y,x1,y1,kar;
void setdot(int x,int y);
void xysel(char x,char y);
void xysel1(char x,char y);
void WriteInstruction(unsigned char x);
void WriteInstruction1(unsigned char x);
void Delay(unsigned int val);
void WriteData(unsigned char y);
void GLCD_Init();
void Glcdclr();
void chip1(){CS1=1;CS2=0;}
void chip2(){CS1=0;CS2=1;}
void chip12(){CS1=1;CS2=1;}
void Writesmall(char u)
{
	char v;
	for(v=0;v<5;v++)
	{
		x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
		WriteData(STRINGsmall[u][v]);
		
	}
}


void Write(char u)
{
	char v;
	for(v=0;v<10;v++)
	{
		x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
		WriteData(STRING[u][v]);
		
	}
xysel1(x1,y1+1);
	for(v=0;v<10;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRING[u+1][v]);
	}
}

/*void Writebig(char u)
{
	char v;
	for(v=0;v<18;v++)
	{
		x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
		WriteData(STRINGbig[u][v]);
		
	}
xysel1(x1,y1+1);
	for(v=0;v<18;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGbig[u+1][v]);
	}
xysel1(x1,y1+2);
	for(v=0;v<18;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGbig[u+2][v]);
	}
}*/
void Writevbig(char u)
{
	char v;
	for(v=0;v<28;v++)
	{
		x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
		WriteData(STRINGvbig[u][v]);
		
	}
xysel1(x1,y1+1);
	for(v=0;v<28;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGvbig[u+1][v]);
	}
xysel1(x1,y1+2);
	for(v=0;v<28;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGvbig[u+2][v]);
	}
xysel1(x1,y1+3);
for(v=0;v<28;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGvbig[u+3][v]);
	}
xysel1(x1,y1+4);
for(v=0;v<28;v++)
	{
	  x_add++;if(x_add==128||x_add==64)xysel(x_add,y_add);
	  WriteData(STRINGvbig[u+4][v]);
	}
}
void xysel(char x,char y)
{
srt:x_add=x;
	y_add=y;
	if(x <64)					//if x falls on the left side of the screen
	{
		kar=1;
		CS1=0;CS2=1;//1,0
		WriteInstruction(0xb8 + y); 	//page
		WriteInstruction(0x40 + x); 	//column
	}
	else if(x>=64&&x<128)    	//if x is greater than 64 and falls on the right side of the screen
	{
		kar=2;
		CS1=1;CS2=0;//0,1
		WriteInstruction(0xb8 + y);	    //page
		WriteInstruction(0x40 + x - 64);//column
	}
	else {x=0;y++;goto srt;}
}
void xysel1(char x,char y)
{
srt:x_add=x;
	y_add=y;
	if(x <64)							//if x falls on the left side of the screen
	{
        kar=1;
		CS1=0;CS2=1;//1,0
		WriteInstruction1(0xb8 + y); 	//page
		WriteInstruction1(0x40 + x); 	//column
	}
	else if(x>=64&&x<128)								//if x is greater than 64 and falls on the right side of the screen
	{
        kar=2;
		CS1=1;CS2=0;//0,1
		WriteInstruction1(0xb8 + y);	    //page
		WriteInstruction1(0x40 + x -64);//column
	}
	else {x=0;y++;goto srt;}
}


void STR_Printsmall(const unsigned char *s,unsigned char x,unsigned char y)
{   
    
	unsigned char u,str;
	while(*s)
	{	
		xysel(x,y);
		str=*s++;
	     if(str=='A'){u=0;}
		else if(str=='B'){u=1;}
		else if(str=='C'){u=2;}
		else if(str=='D'){u=3;}
        else if(str=='E'){u=4;}
		else if(str=='F'){u=5;}
		else if(str=='G'){u=6;}
		else if(str=='H'){u=7;}
else if(str=='I'){u=8;}
else if(str=='J'){u=9;}
else if(str=='K'){u=10;}
else if(str=='L'){u=11;}
else if(str=='M'){u=12;}
else if(str=='N'){u=13;}
else if(str=='O'){u=14;}
else if(str=='P'){u=15;}
else if(str=='Q'){u=16;}
else if(str=='R'){u=17;}
else if(str=='S'){u=18;}
else if(str=='T'){u=19;}
else if(str=='U'){u=20;}
else if(str=='V'){u=21;}
else if(str=='W'){u=22;}
else if(str=='X'){u=23;}
else if(str=='Y'){u=24;}
else if(str=='Z'){u=25;}
else if(str=='*'){u=26;} 

     	
		Writesmall(u);
x=x+7;
	}
}
void STR_Print(const unsigned char *s,unsigned char x,unsigned char y)
{   
    
	unsigned char u,str;
x1=x;y1=y;
	while(*s)
	{	
		xysel(x,y);
		str=*s++;
		/*if(str=='0'){u=0;}
		else if(str=='1'){u=2;}
		else if(str=='2'){u=4;}
		else if(str=='3'){u=6;}
		else if(str=='4'){u=8;}
		else if(str=='5'){u=10;}
		else if(str=='6'){u=12;}
		else if(str=='7'){u=14;}
		else if(str=='8'){u=16;}
		else if(str=='9'){u=18;}
        else if(str=='M'){u=20;}
        else if(str=='O'){u=22;}
        else if(str=='I'){u=24;}
        else if(str=='S'){u=26;}
        else if(str=='T'){u=28;}
        else if(str=='U'){u=30;}
        else if(str=='R'){u=32;}
        else if(str=='E'){u=34;}
        else if(str==' '){u=36;}
        else if(str==':'){u=38;}
*/
        if(str=='.'){u=0;}
		Write(u);
x=x+12;
x1=x;
	}
}

void Delay(unsigned int val)
{
	while(val--);
}
void WriteInstruction_INT(unsigned char x)
{
    CS1=1;CS2=1;
	DI=0;RW=0;
	DATA=x;
	EN=1;Delay(10);
	EN=0;Delay(10);
}
void WriteInstruction(unsigned char x)
{
if(kar==1){CS1=0;CS2=1;}
else if(kar==2){CS1=1;CS2=0;}
	DI=0;RW=0;
	DATA=x;
	EN=1;Delay(10);
	EN=0;Delay(10);
}
void WriteInstruction1(unsigned char x)
{
if(kar==1){CS1=0;CS2=1;}
else if(kar==2){CS1=1;CS2=0;}

	DI=0;RW=0;
	DATA=x;
	EN=1;Delay(10);
	EN=0;Delay(10);
}
void WriteData(unsigned char y)
{
if(kar==1){CS1=0;CS2=1;}
else if(kar==2){CS1=1;CS2=0;}
	DI=1;RW=0;
	DATA=y;
	EN=1;Delay(10);
	EN=0;Delay(10);
}
void GLCD_Init()
{
	DATA=0x00;
	DI=RW=EN=0;RST=0;CS1=CS2=1;
	RST=1;
	WriteInstruction_INT(0x3e);
	WriteInstruction_INT(0xc0);
	WriteInstruction_INT(0x3f);
}
void Glcdclr()
{
	char w,z;
	for(w=0;w<8;w++)
	{
		WriteInstruction(0xb8+w);	//page
		WriteInstruction(0x40);
		chip1();
		for(z=0;z<128;z++)
		{
			if(z==64)
			{
				WriteInstruction(0xb8+w); 	//page
				WriteInstruction(0x40); 
				chip2();
			}
			WriteData(0x00);
		}
	}
}


void setdot(int x,int y)
{
int data;
xysel(x,y);
data=0x01;
WriteData(data);
}