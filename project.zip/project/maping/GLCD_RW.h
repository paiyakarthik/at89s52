#define fq_pulse RA4 
#define fq2_pulse RA5
unsigned int MOI=0,MOI1=0;
volatile unsigned int countmy=0;
int measure(unsigned char );
unsigned int read_freq(unsigned int qq)
{
	unsigned int _frequency;
	TMR1H=0;
	TMR1L=0;
   if(qq==1)
   {		
	while(fq_pulse==0);
	while(fq_pulse==1);
	while(fq_pulse==0);
	TMR1ON=1;
	while(fq_pulse==1);
	while(fq_pulse==0);
	TMR1ON=0;
	_frequency=TMR1H;
	_frequency=((_frequency<<8)+TMR1L);    
	return((unsigned int)(1000000.0/_frequency);
   }
   else if(qq==2)
   {		
	while(fq2_pulse==0);
	while(fq2_pulse==1);
	while(fq2_pulse==0);
	TMR1ON=1;
	while(fq2_pulse==1);
	while(fq2_pulse==0);
	TMR1ON=0;
	_frequency=TMR1H;
	_frequency=((_frequency<<8)+TMR1L);    
	return((unsigned int)(1000000.0/_frequency);
   }
}
int adc_calibrate(float x, float in_min, float in_max)
{
  return ((in_max -x )/(in_max - in_min))*100;
}
int measure(unsigned char channel)
{
unsigned int temp=0,temp1=0;
unsigned int i=0,j=0;
for(j=0;j<38;j++)
{
  temp=read_freq(channel);    
  temp1=temp1+temp;  
} 
temp1=temp1/38;   
return(temp1);
}